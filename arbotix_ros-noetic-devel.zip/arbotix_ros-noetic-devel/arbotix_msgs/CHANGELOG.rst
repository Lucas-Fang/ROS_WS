^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package arbotix_msgs
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.0 (2020-12-29)
-------------------
* Merge pull request `#25 <https://github.com/vanadiumlabs/arbotix_ros/issues/25>`_ from corot/indigo-devel
  Implement issue https://github.com/vanadiumlabs/arbotix_ros/issues/24:
* Implement issue https://github.com/vanadiumlabs/arbotix_ros/issues/24:
  Allow 16 bit values on arbotix_msgs/Analog messages, but assume 8 bits
  by default
* Contributors: Michael Ferguson, corot

0.10.0 (2014-07-14)
-------------------

0.9.2 (2014-02-12)
------------------

0.9.1 (2014-01-28)
------------------
* Added set_speed service to servo controller

0.9.0 (2013-08-22)
------------------
* add new enable service

0.8.2 (2013-03-28)
------------------
* updates to cmakelists.txt and package.xml, fixes `#2 <https://github.com/vanadiumlabs/arbotix_ros/issues/2>`_

0.8.1 (2013-03-09)
------------------

0.8.0 (2013-02-21)
------------------
* import drivers and catkinize
